function printpng(filename,position)
%  printpng( filename, position )

if ~isempty(position),
    width = position(1);
    height = position(2);
    set(gcf,'paperposition',[0,0,width,height])
end


print('-dpng','-r300',filename)

return
