%  This script evaluates the get_waypoint_data.m function for every
%  waypoint data set and generates a plot of the resulting output data.
%
%  This script calls the following functions:
%       get_waypoint_data.m
%       plot_waypoint_data.m

clear, clc

%  --define the configuration parameters

vstart = 0.1;
vmax = 10;
vfinal = 0;

max_alat = 3.25;
max_along = 3.25;

randrotate = false;
plotflag = true;

%  --check to see if the plots folder exists
if (exist('waypoint_plots','dir') == 0)
    %  --create the plots folder
    mkdir('waypoint_plots')
end


%  --loop through each testcase data set

for testcase = 1:12
    %  --get the waypoint data

    [NWP, EWP, HWP, VWP, KWP, ZWP, SWP, GWP, coursename] = get_waypoint_data( ...
        testcase, vstart, vmax, vfinal, max_alat, max_along, randrotate);

    %  --plot the waypoint data
    plotfilename = sprintf('./waypoint_plots/vref_data_%d.png',testcase);
    plot_waypoint_data(NWP, EWP, HWP, VWP, KWP, ZWP, SWP, coursename, ...
        vmax, max_along, max_alat, plotfilename);
end

